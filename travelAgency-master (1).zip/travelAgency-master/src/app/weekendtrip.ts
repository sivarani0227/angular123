export interface Weekendtrip {
    id: number; src: string;
        destination: string; fare: number;
}
