export interface TravelAgent {
    id: number; name: string; location: string;
     mobileNumber: number;
}
