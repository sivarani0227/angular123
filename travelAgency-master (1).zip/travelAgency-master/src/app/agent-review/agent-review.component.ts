import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-review',
  templateUrl: './agent-review.component.html',
  styleUrls: ['./agent-review.component.css']
})
export class AgentReviewComponent implements OnInit {

  reviews: any;
  constructor() { }

  ngOnInit() {
  }

}
